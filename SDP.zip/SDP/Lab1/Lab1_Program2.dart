void main() {
  int i;
  for (i = 0; i < 5; i++) print("hello ${i + 1}");
}
