package com.example.sdp_lab_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
