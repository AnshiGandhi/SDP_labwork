import 'package:lab_2_tutorial_2/lab_2_tutorial_2.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
