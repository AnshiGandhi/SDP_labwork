import 'package:lab_2_tutorial_3/lab_2_tutorial_3.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
