import 'package:lab_5_tutorial_2/lab_5_tutorial_2.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
