import 'package:lab_3_tutorial_1/lab_3_tutorial_1.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
