import 'package:lab_3_tutorial_3/lab_3_tutorial_3.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
