package com.example.sdp_lab_10_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
